<?php
/**
* Load the stylesheet from the parent theme with theme version added automatically.
*
*/
function theme_name_parent_styles() {
 
$parent = get_template();
$parent = wp_get_theme( $parent );
 
// Enqueue the parent stylesheet
//wp_enqueue_style( 'theme-name-parent-style', get_template_directory_uri() . '/css/style.css', array(), $parent['Version'], 'all' );
 
// Enqueue the parent rtl stylesheet
if ( is_rtl() ) {
wp_enqueue_style( 'theme-name-parent-style-rtl', get_template_directory_uri() . '/rtl.css', array(), $parent['Version'], 'all' );
}
}
add_action( 'wp_enqueue_scripts', 'theme_name_parent_styles' );

/**
* Load child theme sytlesheets
*
*/
function child_theme_styles() {
wp_dequeue_style( 'parent-theme-style' );
wp_enqueue_style( 'child-theme-style', get_stylesheet_directory_uri() .'/css/style.css' );
}
add_action( 'wp_enqueue_scripts', 'child_theme_styles', 99 );

function add_child_scripts() {

  wp_register_script( 'childscripts', get_stylesheet_directory_uri() . '/js/scripts.js', array('jquery'),'', true);
  wp_enqueue_script( 'childscripts' );

}

add_action( 'wp_enqueue_scripts', 'add_child_scripts' );
